interface StatsCardsProps {
  stats?: {
    totalLogs: number;
    totalCustomers: number;
    totalVehicles: number;
  };
}

export function StatsCards({ stats }: StatsCardsProps) {
  if (!stats) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white p-6 rounded-lg shadow animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          </div>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: "Total Log Entries",
      value: stats.totalLogs,
      icon: "📋",
      color: "bg-blue-500",
    },
    {
      title: "Total Customers",
      value: stats.totalCustomers,
      icon: "👥",
      color: "bg-green-500",
    },
    {
      title: "Total Vehicles",
      value: stats.totalVehicles,
      icon: "🚗",
      color: "bg-purple-500",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {cards.map((card) => (
        <div key={card.title} className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className={`${card.color} p-3 rounded-lg text-white text-xl mr-4`}>
              {card.icon}
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">{card.title}</p>
              <p className="text-2xl font-bold text-gray-900">{card.value}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
