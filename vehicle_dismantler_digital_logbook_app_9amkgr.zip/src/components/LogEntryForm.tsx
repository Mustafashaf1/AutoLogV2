import { useState, useRef } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";
import { CustomerForm } from "./CustomerForm";
import { VehicleForm } from "./VehicleForm";
import { CameraCapture } from "./CameraCapture";

interface LogEntryFormProps {
  onSuccess?: () => void;
}

export function LogEntryForm({ onSuccess }: LogEntryFormProps) {
  const [customerId, setCustomerId] = useState<Id<"customers"> | "">("");
  const [vehicleId, setVehicleId] = useState<Id<"vehicles"> | "">("");
  const [notes, setNotes] = useState("");
  const [status, setStatus] = useState<"received" | "processing" | "completed">("received");
  const [estimatedValue, setEstimatedValue] = useState("");
  const [vehiclePhotos, setVehiclePhotos] = useState<Id<"_storage">[]>([]);
  const [showCustomerForm, setShowCustomerForm] = useState(false);
  const [showVehicleForm, setShowVehicleForm] = useState(false);
  const [showCamera, setShowCamera] = useState(false);

  const customers = useQuery(api.customers.list);
  const vehicles = useQuery(api.vehicles.list);
  const createLogEntry = useMutation(api.logEntries.create);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!customerId || !vehicleId) {
      toast.error("Please select both a customer and vehicle");
      return;
    }

    try {
      await createLogEntry({
        customerId: customerId as Id<"customers">,
        vehicleId: vehicleId as Id<"vehicles">,
        notes: notes || undefined,
        status,
        estimatedValue: estimatedValue ? parseFloat(estimatedValue) : undefined,
        vehiclePhotos,
      });

      toast.success("Log entry created successfully");
      
      // Reset form
      setCustomerId("");
      setVehicleId("");
      setNotes("");
      setStatus("received");
      setEstimatedValue("");
      setVehiclePhotos([]);
      
      onSuccess?.();
    } catch (error) {
      toast.error("Failed to create log entry");
      console.error(error);
    }
  };

  const handlePhotoCapture = (photoId: Id<"_storage">) => {
    setVehiclePhotos(prev => [...prev, photoId]);
    setShowCamera(false);
  };

  const removePhoto = (index: number) => {
    setVehiclePhotos(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="max-w-2xl mx-auto bg-white p-4 md:p-6 rounded-lg shadow">
      <form onSubmit={handleSubmit} className="space-y-4 md:space-y-6">
        {/* Customer Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Customer
          </label>
          <div className="flex gap-2">
            <select
              value={customerId}
              onChange={(e) => setCustomerId(e.target.value as Id<"customers"> | "")}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            >
              <option value="">Select a customer</option>
              {customers?.map((customer) => (
                <option key={customer._id} value={customer._id}>
                  {customer.firstName} {customer.lastName}
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={() => setShowCustomerForm(true)}
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              New
            </button>
          </div>
        </div>

        {/* Vehicle Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Vehicle
          </label>
          <div className="flex gap-2">
            <select
              value={vehicleId}
              onChange={(e) => setVehicleId(e.target.value as Id<"vehicles"> | "")}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            >
              <option value="">Select a vehicle</option>
              {vehicles?.map((vehicle) => (
                <option key={vehicle._id} value={vehicle._id}>
                  {vehicle.year} {vehicle.make} {vehicle.model}
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={() => setShowVehicleForm(true)}
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              New
            </button>
          </div>
        </div>

        {/* Status */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Status
          </label>
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value as "received" | "processing" | "completed")}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="received">Received</option>
            <option value="processing">Processing</option>
            <option value="completed">Completed</option>
          </select>
        </div>

        {/* Estimated Value */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Estimated Value (NZD)
          </label>
          <input
            type="number"
            step="0.01"
            value={estimatedValue}
            onChange={(e) => setEstimatedValue(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="0.00"
          />
        </div>

        {/* Vehicle Photos */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Vehicle Photos
          </label>
          <div className="space-y-3">
            <button
              type="button"
              onClick={() => setShowCamera(true)}
              className="w-full px-4 py-2 border-2 border-dashed border-gray-300 rounded-md text-gray-600 hover:border-gray-400 hover:text-gray-700"
            >
              📷 Take Photo
            </button>
            
            {vehiclePhotos.length > 0 && (
              <div className="grid grid-cols-3 gap-2">
                {vehiclePhotos.map((photoId, index) => (
                  <div key={index} className="relative">
                    <img
                      src={`/api/storage/${photoId}`}
                      alt={`Vehicle photo ${index + 1}`}
                      className="w-full h-24 object-cover rounded border"
                    />
                    <button
                      type="button"
                      onClick={() => removePhoto(index)}
                      className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Notes */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Notes
          </label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={4}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Additional notes about the vehicle or dismantling process..."
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          Create Log Entry
        </button>
      </form>

      {/* Modals */}
      {showCustomerForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4">
            <CustomerForm
              onSuccess={(id) => {
                setCustomerId(id);
                setShowCustomerForm(false);
              }}
              onCancel={() => setShowCustomerForm(false)}
            />
          </div>
        </div>
      )}

      {showVehicleForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4">
            <VehicleForm
              onSuccess={(id) => {
                setVehicleId(id);
                setShowVehicleForm(false);
              }}
              onCancel={() => setShowVehicleForm(false)}
            />
          </div>
        </div>
      )}

      {showCamera && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4">
            <CameraCapture
              onCapture={handlePhotoCapture}
              onCancel={() => setShowCamera(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
}
