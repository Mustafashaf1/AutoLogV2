import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

interface LogEntriesListProps {
  limit?: number;
}

export function LogEntriesList({ limit }: LogEntriesListProps) {
  const logEntries = useQuery(api.logEntries.list);

  if (!logEntries) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white p-4 rounded-lg shadow animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
            <div className="h-3 bg-gray-200 rounded w-1/3"></div>
          </div>
        ))}
      </div>
    );
  }

  const displayEntries = limit ? logEntries.slice(0, limit) : logEntries;

  if (displayEntries.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <p>No log entries found.</p>
        <p className="text-sm">Create your first log entry to get started.</p>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "received":
        return "bg-blue-100 text-blue-800";
      case "processing":
        return "bg-yellow-100 text-yellow-800";
      case "completed":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="space-y-4">
      {displayEntries.map((entry) => (
        <div key={entry._id} className="bg-white p-4 rounded-lg shadow border">
          <div className="flex justify-between items-start mb-3">
            <div>
              <h3 className="font-semibold text-lg">
                {entry.vehicle?.year} {entry.vehicle?.make} {entry.vehicle?.model}
              </h3>
              <p className="text-gray-600">
                Customer: {entry.customer?.firstName} {entry.customer?.lastName}
              </p>
            </div>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(entry.status)}`}>
              {entry.status.charAt(0).toUpperCase() + entry.status.slice(1)}
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600 mb-3">
            <div>
              <span className="font-medium">Date:</span>
              <br />
              {new Date(entry.entryDate).toLocaleDateString()}
            </div>
            {entry.vehicle?.vin && (
              <div>
                <span className="font-medium">VIN:</span>
                <br />
                {entry.vehicle.vin}
              </div>
            )}
            {entry.vehicle?.licensePlate && (
              <div>
                <span className="font-medium">License:</span>
                <br />
                {entry.vehicle.licensePlate}
              </div>
            )}
            {entry.estimatedValue && (
              <div>
                <span className="font-medium">Est. Value:</span>
                <br />
                ${entry.estimatedValue.toFixed(2)} NZD
              </div>
            )}
          </div>

          {entry.notes && (
            <div className="mb-3">
              <span className="font-medium text-sm text-gray-700">Notes:</span>
              <p className="text-sm text-gray-600 mt-1">{entry.notes}</p>
            </div>
          )}

          {entry.vehiclePhotos.length > 0 && (
            <div>
              <span className="font-medium text-sm text-gray-700">Photos:</span>
              <div className="flex gap-2 mt-2">
                {entry.vehiclePhotos.slice(0, 3).map((photoId, index) => (
                  <img
                    key={index}
                    src={`/api/storage/${photoId}`}
                    alt={`Vehicle photo ${index + 1}`}
                    className="w-16 h-16 object-cover rounded border"
                  />
                ))}
                {entry.vehiclePhotos.length > 3 && (
                  <div className="w-16 h-16 bg-gray-100 rounded border flex items-center justify-center text-xs text-gray-500">
                    +{entry.vehiclePhotos.length - 3}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
