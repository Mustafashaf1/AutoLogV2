import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { LogEntryForm } from "./LogEntryForm";
import { LogEntriesList } from "./LogEntriesList";
import { CustomersList } from "./CustomersList";
import { VehiclesList } from "./VehiclesList";
import { StatsCards } from "./StatsCards";

type Tab = "dashboard" | "new-log" | "logs" | "customers" | "vehicles";

export function Dashboard() {
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");
  const stats = useQuery(api.logEntries.getStats);

  const tabs = [
    { id: "dashboard" as const, label: "Dashboard", icon: "📊" },
    { id: "new-log" as const, label: "New Log", icon: "➕" },
    { id: "logs" as const, label: "Log Entries", icon: "📋" },
    { id: "customers" as const, label: "Customers", icon: "👥" },
    { id: "vehicles" as const, label: "Vehicles", icon: "🚗" },
  ];

  return (
    <div className="space-y-6">
      {/* Navigation Tabs */}
      <div className="bg-white rounded-lg shadow-sm border overflow-hidden">
        <nav className="flex overflow-x-auto scrollbar-hide">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-shrink-0 px-4 py-3 font-medium text-sm transition-all duration-200 ${
                activeTab === tab.id
                  ? "bg-blue-600 text-white"
                  : "text-gray-600 hover:text-blue-600 hover:bg-blue-50"
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              <span className="whitespace-nowrap">{tab.label}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      <div className="min-h-[600px]">
        {activeTab === "dashboard" && (
          <div className="space-y-6">
            <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
            <StatsCards stats={stats} />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
              <div className="bg-white p-6 rounded-lg shadow">
                <h2 className="text-lg font-semibold mb-4">Recent Log Entries</h2>
                <LogEntriesList limit={5} />
              </div>
              <div className="bg-white p-6 rounded-lg shadow">
                <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
                <div className="space-y-3">
                  <button
                    onClick={() => setActiveTab("new-log")}
                    className="w-full bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors"
                  >
                    Create New Log Entry
                  </button>
                  <button
                    onClick={() => setActiveTab("customers")}
                    className="w-full bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition-colors"
                  >
                    Manage Customers
                  </button>
                  <button
                    onClick={() => setActiveTab("vehicles")}
                    className="w-full bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700 transition-colors"
                  >
                    Manage Vehicles
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "new-log" && (
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-6">Create New Log Entry</h1>
            <LogEntryForm onSuccess={() => setActiveTab("logs")} />
          </div>
        )}

        {activeTab === "logs" && (
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-6">Log Entries</h1>
            <LogEntriesList />
          </div>
        )}

        {activeTab === "customers" && (
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-6">Customers</h1>
            <CustomersList />
          </div>
        )}

        {activeTab === "vehicles" && (
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-6">Vehicles</h1>
            <VehiclesList />
          </div>
        )}
      </div>
    </div>
  );
}
