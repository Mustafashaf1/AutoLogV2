import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const create = mutation({
  args: {
    firstName: v.string(),
    lastName: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    address: v.optional(v.string()),
    idNumber: v.optional(v.string()),
    idType: v.optional(v.string()),
    idPhotoId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    return await ctx.db.insert("customers", {
      ...args,
      userId,
    });
  },
});

export const list = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    return await ctx.db
      .query("customers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
  },
});

export const get = query({
  args: { id: v.id("customers") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const customer = await ctx.db.get(args.id);
    if (!customer || customer.userId !== userId) {
      return null;
    }

    return customer;
  },
});

export const update = mutation({
  args: {
    id: v.id("customers"),
    firstName: v.optional(v.string()),
    lastName: v.optional(v.string()),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    address: v.optional(v.string()),
    idNumber: v.optional(v.string()),
    idType: v.optional(v.string()),
    idPhotoId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const { id, ...updates } = args;
    const customer = await ctx.db.get(id);
    
    if (!customer || customer.userId !== userId) {
      throw new Error("Customer not found or unauthorized");
    }

    await ctx.db.patch(id, updates);
  },
});

export const remove = mutation({
  args: {
    id: v.id("customers"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const customer = await ctx.db.get(args.id);
    
    if (!customer || customer.userId !== userId) {
      throw new Error("Customer not found or unauthorized");
    }

    // Check if customer has any log entries
    const logEntries = await ctx.db
      .query("logEntries")
      .withIndex("by_customer", (q) => q.eq("customerId", args.id))
      .collect();

    if (logEntries.length > 0) {
      throw new Error("Cannot delete customer with existing log entries");
    }

    await ctx.db.delete(args.id);
  },
});
