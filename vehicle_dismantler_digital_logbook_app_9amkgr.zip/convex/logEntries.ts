import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const create = mutation({
  args: {
    customerId: v.id("customers"),
    vehicleId: v.id("vehicles"),
    notes: v.optional(v.string()),
    vehiclePhotos: v.array(v.id("_storage")),
    status: v.union(v.literal("received"), v.literal("processing"), v.literal("completed")),
    estimatedValue: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    // Verify customer and vehicle belong to user
    const customer = await ctx.db.get(args.customerId);
    const vehicle = await ctx.db.get(args.vehicleId);

    if (!customer || customer.userId !== userId) {
      throw new Error("Customer not found or unauthorized");
    }

    if (!vehicle || vehicle.userId !== userId) {
      throw new Error("Vehicle not found or unauthorized");
    }

    return await ctx.db.insert("logEntries", {
      ...args,
      userId,
      entryDate: Date.now(),
    });
  },
});

export const list = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const entries = await ctx.db
      .query("logEntries")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();

    // Get customer and vehicle data for each entry
    const enrichedEntries = await Promise.all(
      entries.map(async (entry) => {
        const customer = await ctx.db.get(entry.customerId);
        const vehicle = await ctx.db.get(entry.vehicleId);
        
        return {
          ...entry,
          customer,
          vehicle,
        };
      })
    );

    return enrichedEntries;
  },
});

export const get = query({
  args: { id: v.id("logEntries") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const entry = await ctx.db.get(args.id);
    if (!entry || entry.userId !== userId) {
      return null;
    }

    const customer = await ctx.db.get(entry.customerId);
    const vehicle = await ctx.db.get(entry.vehicleId);

    return {
      ...entry,
      customer,
      vehicle,
    };
  },
});

export const update = mutation({
  args: {
    id: v.id("logEntries"),
    notes: v.optional(v.string()),
    status: v.optional(v.union(v.literal("received"), v.literal("processing"), v.literal("completed"))),
    estimatedValue: v.optional(v.number()),
    actualValue: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const { id, ...updates } = args;
    const entry = await ctx.db.get(id);
    
    if (!entry || entry.userId !== userId) {
      throw new Error("Log entry not found or unauthorized");
    }

    await ctx.db.patch(id, updates);
  },
});

export const getStats = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return { totalLogs: 0, totalCustomers: 0, totalVehicles: 0 };
    }

    const logs = await ctx.db
      .query("logEntries")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const customers = await ctx.db
      .query("customers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const vehicles = await ctx.db
      .query("vehicles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    return {
      totalLogs: logs.length,
      totalCustomers: customers.length,
      totalVehicles: vehicles.length,
    };
  },
});
