import { httpRouter } from "convex/server";
import { httpAction } from "./_generated/server";

const http = httpRouter();

// Storage endpoint for serving images
http.route({
  path: "/api/storage/{storageId}",
  method: "GET",
  handler: httpAction(async (ctx, request) => {
    const url = new URL(request.url);
    const storageId = url.pathname.split('/').pop();
    
    if (!storageId) {
      return new Response("Storage ID required", { status: 400 });
    }

    try {
      const fileUrl = await ctx.storage.getUrl(storageId);
      
      if (!fileUrl) {
        return new Response("File not found", { status: 404 });
      }

      // Redirect to the signed URL
      return new Response(null, {
        status: 302,
        headers: {
          Location: fileUrl,
        },
      });
    } catch (error) {
      console.error("Error serving file:", error);
      return new Response("Internal server error", { status: 500 });
    }
  }),
});

export default http;
