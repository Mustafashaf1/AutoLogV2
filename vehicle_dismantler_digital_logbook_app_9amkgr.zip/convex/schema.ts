import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  customers: defineTable({
    firstName: v.string(),
    lastName: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    address: v.optional(v.string()),
    idNumber: v.optional(v.string()),
    idType: v.optional(v.string()),
    idPhotoId: v.optional(v.id("_storage")),
    userId: v.id("users"),
  }).index("by_user", ["userId"]),

  vehicles: defineTable({
    make: v.string(),
    model: v.string(),
    year: v.number(),
    vin: v.optional(v.string()),
    licensePlate: v.optional(v.string()),
    color: v.optional(v.string()),
    mileage: v.optional(v.number()),
    condition: v.optional(v.string()),
    userId: v.id("users"),
  }).index("by_user", ["userId"]),

  logEntries: defineTable({
    customerId: v.id("customers"),
    vehicleId: v.id("vehicles"),
    userId: v.id("users"),
    entryDate: v.number(),
    notes: v.optional(v.string()),
    vehiclePhotos: v.array(v.id("_storage")),
    status: v.union(v.literal("received"), v.literal("processing"), v.literal("completed")),
    estimatedValue: v.optional(v.number()),
    actualValue: v.optional(v.number()),
  })
    .index("by_user", ["userId"])
    .index("by_date", ["entryDate"])
    .index("by_customer", ["customerId"])
    .index("by_vehicle", ["vehicleId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
